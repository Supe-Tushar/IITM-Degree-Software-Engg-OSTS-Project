# Online Support Ticket Application
# Tushar Supe : 21f1003637
# Vaidehi Agarwal: 21f1003880
# File Info: This file initiates sqlalchemy.

# --------------------  Imports  --------------------

from flask_sqlalchemy import SQLAlchemy

# --------------------  Code  --------------------

db = SQLAlchemy()

# --------------------  END  --------------------
